#Date Time
from datetime import datetime
d=datetime.now()
print d
print d.year
print d.month
print d.day
print d.hour
print d.minute
print d.second

indian_date=str(d.day) + '/' + str(d.month) + '/' + str(d.year)
print indian_date










#performance measurement

import time

starttime=time.time()

for x in range(1000):
	print x**x

endtime=time.time()

print(endtime-starttime)







