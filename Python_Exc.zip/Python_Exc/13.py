name=raw_input("Please enter your name:\n")
print "Hello",name