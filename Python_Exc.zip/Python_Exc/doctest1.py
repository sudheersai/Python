def _test():
        import doctest, doctest2   #The module name 
        return doctest.testmod(doctest2)

if __name__ == "__main__":
        _test()