#regex examples
import re
#finding
r=re.findall('\d+','13 blue pens,9 balls,6 books and 20 rupees')
print r


#splitting
r=re.split('[,:-]',"Ramesh,223-rsannareddy@yahoo.com:Trainer")
print r


#matching
r=re.match('ba',"ba ba blacksheep ba ba blacksheep")
print r

#matching
r=re.search('\w{10}',"ba ba blacksheep ba ba blacksheep")
print r
print r.group()
print r.span()
















print re.sub('\d','*',a)
print re.sub('0?[7-9]\d{9}','*',a)








#compiled regex
r = re.compile('\d+')
result=r.findall('He has 13 blue pens, 9 balls, 6 books and 20 rupees')
print result

r = re.compile('\d+')
it=r.finditer('He has 13 blue pens, 9 balls, 6 books and 20 rupees')
for match in it:
	print match.span()

