import subprocess
# Simple command
subprocess.call(['ls', '-1'], shell=True)


#checking the output

output = subprocess.check_output(['ls', '-1'])
print 'Have %d bytes in output' % len(output)
print output
