import os,time
for (dirname, subdir, files) in os.walk('c:/users/tring/desktop'):
	for myfile in files:
		filename=os.path.join(dirname,myfile)
		if filename.endswith('.py') and os.stat(filename).st_size<1024 and (time.time()-os.stat(filename).st_ctime) < 60*60*24*4 :
			print(filename)
			
