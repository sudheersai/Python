#while loop

numRocketsToFire = 10
rocketCount = 0

while rocketCount < numRocketsToFire:
    # Increase the rocket counter by one
    rocketCount = rocketCount + 1
    print( "Firing rocket #" + str( rocketCount ) )

